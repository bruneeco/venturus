import express from "express";
import { seguirUsuario, deixarDeSeguir, listarSeguidores, listarSeguindo } from "../controllers/seguidores.js";

const router = express.Router();
router.post("/", seguirUsuario);
router.delete("/", deixarDeSeguir);
router.get("/seguindo/:usuario_id", listarSeguindo); 
router.get("/:usuario_id", listarSeguidores);
export default router;
