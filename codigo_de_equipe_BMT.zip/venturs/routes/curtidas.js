import express from "express";
import { adicionarCurtida } from "../controllers/curtidas.js";
import { removerCurtida } from "../controllers/curtidas.js";


const router = express.Router();


router.post("/publicacao", adicionarCurtida);
router.delete("/publicacao", removerCurtida);



export default router;
