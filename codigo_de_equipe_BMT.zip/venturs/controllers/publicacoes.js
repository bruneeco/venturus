import Publicacoes from "../models/Publicacoes.js";
import Usuarios from "../models/Usuarios.js";
import Comentarios from "../models/Comentarios.js";

// criar uma nova publicacao
export const criarPublicacao = async (req, res) => {
  const { publicacao, usuario_id } = req.body;

  if (!publicacao || !usuario_id) {
    return res.status(400).json({ erro: "Campos obrigatórios: publicacao e usuario_id" });
  }

  try {
    const usuario = await Usuarios.findByPk(usuario_id);
    if (!usuario) return res.status(400).json({ erro: "Usuário não encontrado" });

    const novaPublicacao = await Publicacoes.create({ publicacao, usuario_id });
    res.status(201).json({ publicacao_id: novaPublicacao.id });
  } catch (erro) {
    console.error("Erro ao criar publicação:", erro);
    res.status(500).json({ erro: "Erro ao criar publicação" });
  }
};

// listar todas as publicacoes
export const listarPublicacoes = async (req, res) => {
  try {
    const publicacoes = await Publicacoes.findAll({
      include: [{ model: Usuarios, as: 'usuario', attributes: ["nick", "imagem"] }],
    });

    const data = publicacoes.map(publicacao => ({
      publicacao_id: publicacao.id,
      publicacao: publicacao.publicacao,
      usuario_id: publicacao.usuario_id,
      nick: publicacao.usuario.nick,
      imagem: publicacao.usuario.imagem,
      qtd_likes: publicacao.qtd_likes,
      criado_em: publicacao.criado_em,
    }));

    res.status(200).json({ data: data, total: data.length });
  } catch (erro) {
    console.error("Erro ao buscar publicações:", erro);
    res.status(500).json({ erro: "Erro ao buscar publicações" });
  }
};

// listar publicacoes de um usuario
export const listarPublicacoesDeUsuario = async (req, res) => {
  const { usuario_id } = req.params;

  try {
    const usuario = await Usuarios.findByPk(usuario_id);
    if (!usuario) return res.status(404).json({ erro: "Usuário não encontrado" });

    const publicacoes = await Publicacoes.findAll({
      where: { usuario_id },
      include: [{ model: Usuarios, as: 'usuario', attributes: ["nick", "imagem"] }],
    });

    const data = await Promise.all(publicacoes.map(async (publicacao) => ({
      publicacao_id: publicacao.id,
      publicacao: publicacao.publicacao,
      usuario_id: publicacao.usuario_id,
      nick: publicacao.usuario.nick,
      imagem: publicacao.usuario.imagem,
      qtd_likes: publicacao.qtd_likes,
      qtd_comentarios: await Comentarios.count({ where: { publicacao_id: publicacao.id } }),
      criado_em: publicacao.createdAt,
    })))

    res.status(200).json({ data, total: data.length });
  } catch (erro) {
    console.error("Erro ao listar publicações do usuário:", erro);
    res.status(500).json({ erro: "Erro ao listar publicações do usuário" });
  }
};


// deletar uma publicacao e seus comentarios
export const deletarPublicacao = async (req, res) => {
  const { publicacao_id, usuario_id } = req.body;

  if (!publicacao_id || !usuario_id) {
    return res.status(400).json({ erro: "Campos obrigatórios: publicacao_id e usuario_id" });
  }

  try {
    const publicacao = await Publicacoes.findByPk(publicacao_id);
    if (!publicacao) return res.status(400).json({ erro: "Publicação não encontrada" });

    const usuario = await Usuarios.findByPk(usuario_id);
    if (!usuario) return res.status(400).json({ erro: "Usuário não encontrado" });

    if (publicacao.usuario_id !== usuario_id) {
      return res.status(403).json({ erro: "Usuário não autorizado" });
    }

    await Comentarios.destroy({ where: { publicacao_id } });
    await publicacao.destroy();

    res.status(200).json({ mensagem: "Publicação e comentários deletados com sucesso" });
  } catch (erro) {
    console.error("Erro ao deletar publicação:", erro);
    res.status(500).json({ erro: "Erro ao deletar publicação" });
  }
};
