import Usuario from "../models/Usuarios.js";
import { Op } from "sequelize"; 
import bcrypt from "bcrypt"; 

// Criar um novo usuario
export const criarUsuario = async (req, res) => {
  try {
    const { nome, nick, email, senha, nascimento, imagem } = req.body;
    // Validação de campos obrigatórios
    if (!nome || !nick || !email || !senha || !nascimento) {
      return res.status(400).json({ erro: "Todos os campos são obrigatórios" });
    }
    // Verifica se o email já existe
    const emailExistente = await Usuario.findOne({ where: { email } });
    if (emailExistente) {
      return res.status(400).json({ erro: "Email já está em uso" });
    }
    // Verifica se o nick já existe
    const nickExistente = await Usuario.findOne({ where: { nick } });
    if (nickExistente) {
      return res.status(400).json({ erro: "Nick já está em uso" });
    }
    
    const senhaHashed = await bcrypt.hash(senha, 10); 

    // Criação do usuário
    const usuario = await Usuario.create({
      nome,
      nick,
      email,
      senha: senhaHashed,
      nascimento,
      imagem,
    });

    res.status(201).json({
      mensagem: "Usuário criado com sucesso",
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        nick: usuario.nick,
        email: usuario.email,
        nascimento: usuario.nascimento,
        imagem: usuario.imagem,
      },
    });
  } catch (erro) {
    console.error("Erro ao criar usuário:", erro);
    res.status(500).json({ erro: "Erro ao criar usuário", details: erro });
  }
};


// listar usuarios 
export const listarUsuarios = async (req, res) => {
  try {
    const { search } = req.query;

    const filtro = search
      ? {
          where: {
            [Op.or]: [
              { nome: { [Op.like]: `%${search}%` } },
              { nick: { [Op.like]: `%${search}%` } },
            ],
          },
        }
      : {};
    const usuarios = await Usuario.findAll({
      ...filtro,
      attributes: ["id", "nome", "email", "nick", "imagem", "nascimento"],
    });
    res.status(200).json(usuarios);
  } catch (erro) {
    console.error("Erro ao buscar usuários:", erro);
    res.status(500).json({ erro: "Erro ao buscar usuários" });
  }
};





// Buscar um usuario por id
export const buscarUsuarioPorId = async (req, res) => {
    try {
      const { usuario_id } = req.params; // Extrai o ID do usuario dos parametros da url
      const usuario = await Usuario.findByPk(usuario_id, {
        attributes: ["nome", "email", "nick", "imagem", "nascimento"],
      });
      if (!usuario) {
        return res.status(404).json({ erro: "Usuário não encontrado" });
      }
      res.status(200).json(usuario);
    } catch (erro) {
      console.error("Erro ao buscar detalhes do usuário:", erro);
      res.status(500).json({ erro: "Erro ao buscar detalhes do usuário" });
    }
  };

// Atualizar um usuário por ID
export const atualizarUsuario = async (req, res) => {
    try {
      const { usuario_id } = req.params;
      const { nome, email, nick, imagem} = req.body;
      if (!nome && !email && !nick && !imagem) {
        return res
          .status(400)
          .json({ erro: "Pelo menos um campo deve ser fornecido para atualização" });
      }
      const usuario = await Usuario.findByPk(usuario_id);
      if (!usuario) {
        return res.status(404).json({ erro: "Usuário não encontrado" });
      }
      // Verifica se o email ja esta em uso
      if (email) {
        const emailExistente = await Usuario.findOne({
          where: { email, id: { [Op.ne]: usuario_id } },
        });
        if (emailExistente) {
          return res.status(400).json({ erro: "Email já está em uso" });
        }
      }
      // Verifica se o nick ja esta em uso
      if (nick) {
        const nickExistente = await Usuario.findOne({
          where: { nick, id: { [Op.ne]: usuario_id } },
        });
        if (nickExistente) {
          return res.status(400).json({ erro: "Nick já está em uso" });
        }
      }
      // Atualiza os campos fornecidos
      if (nome) usuario.nome = nome;
      if (email) usuario.email = email;
      if (nick) usuario.nick = nick;
      if (imagem) usuario.imagem = imagem;
      await usuario.save();
      res.status(200).json({
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        nick: usuario.nick,
        imagem: usuario.imagem,
        nascimento: usuario.nascimento,
      });
    } catch (erro) {
      console.error("Erro ao atualizar usuário:", erro);
      res.status(500).json({ erro: "Erro ao atualizar usuário" });
    }
  };
