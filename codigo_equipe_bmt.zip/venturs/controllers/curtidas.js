import Publicacoes from "../models/Publicacoes.js";
import Comentarios from "../models/Comentarios.js";


// adicionar uma curtida a uma publicacao
export const adicionarCurtida = async (req, res) => {
  const { publicacao_id } = req.body;

  if (!publicacao_id) {
    return res.status(400).json({ erro: "Por favor, forneça o ID da publicação para adicionar uma curtida." });
  }

  try {
    const publicacao = await Publicacoes.findByPk(publicacao_id);
    if (!publicacao) {
      return res.status(404).json({ erro: "Publicação não encontrada. Verifique o ID da publicação." });
    }

    // Incrementa a quantidade de curtidas
    publicacao.qtd_likes += 1;
    await publicacao.save();

    res.status(200).json({ mensagem: "Curtida adicionada com sucesso!", qtd_likes: publicacao.qtd_likes });
  } catch (erro) {
    console.error("Erro ao adicionar curtida:", erro);
    res.status(500).json({ erro: "Houve um erro ao tentar adicionar a curtida. Por favor, tente novamente mais tarde." });
  }
};

// remover uma curtida de uma publicacao
export const removerCurtida = async (req, res) => {
  const { publicacao_id } = req.body;

  if (!publicacao_id) {
    return res.status(400).json({ erro: "Por favor, forneça o ID da publicação para remover a curtida." });
  }

  try {
    const publicacao = await Publicacoes.findByPk(publicacao_id);
    if (!publicacao) {
      return res.status(404).json({ erro: "Publicação não encontrada. Verifique o ID da publicação." });
    }

    // decrementa a quantidade de curtidas, mas nao permite valores negativos
    if (publicacao.qtd_likes > 0) {
      publicacao.qtd_likes -= 1;
    }

    await publicacao.save();

    res.status(200).json({ mensagem: "Curtida removida com sucesso!", qtd_likes: publicacao.qtd_likes });
  } catch (erro) {
    console.error("Erro ao remover curtida:", erro);
    res.status(500).json({ erro: "Houve um erro ao tentar remover a curtida. Por favor, tente novamente mais tarde." });
  }
};

export const adicionarCurtidaComentario = async (req, res) => {
  const {comentario_id} = req.body;
 
 
 if (!comentario_id) {
    return res.status(400).json({ erro: "Por favor, forneça o ID da publicação para adicionar uma curtida." });
  }

  try {
    const comentario = await Comentarios.findByPk(comentario_id);
    if (!comentario) {
      return res.status(404).json({ erro: "Publicação não encontrada. Verifique o ID da publicação." });
    }

    // Incrementa a quantidade de curtidas
    comentario.qtd_likes += 1;
    await comentario.save();

    res.status(200).json({ mensagem: "Curtida adicionada com sucesso!", qtd_likes: comentario.qtd_likes });
  } catch (erro) {
    console.error("Erro ao adicionar curtida:", erro);
    res.status(500).json({ erro: "Houve um erro ao tentar adicionar a curtida. Por favor, tente novamente mais tarde." });
  }
};



// remover uma curtida de um comentario
export const removerCurtidaComentario = async (req, res) => {
  const { comentario_id } = req.body;
  if (!comentario_id) {
    return res.status(400).json({ erro: "Por favor, forneça o ID do comentário para remover a curtida." });
  }

  try {
    const comentario = await Comentarios.findByPk(comentario_id);
    if (!comentario_id) {
      return res.status(404).json({ erro: "Comentário não encontrado. Verifique o ID do comentário." });
    }

    if (comentario.qtd_likes > 0) {
      comentario.qtd_likes -= 1;
    }

    await comentario.save();

    res.status(200).json({ mensagem: "Curtida do comentário removida com sucesso!", qtd_likes: comentario.qtd_likes });
  } catch (erro) {
    console.error("Erro ao remover curtida do comentário:", erro);
    res.status(500).json({ erro: "Houve um erro ao tentar remover a curtida do comentário. Por favor, tente novamente mais tarde." });
  }
};



  