import express from "express";
import { adicionarCurtida, adicionarCurtidaComentario, removerCurtidaComentario } from "../controllers/curtidas.js";
import { removerCurtida } from "../controllers/curtidas.js";


const router = express.Router();


router.post("/publicacao", adicionarCurtida);
router.delete("/publicacao", removerCurtida);
router.post("/comentario", adicionarCurtidaComentario);
router.delete("/comentario", removerCurtidaComentario);


export default router;
