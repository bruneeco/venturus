import express from "express";
import { 
  criarComentario, 
  deletarComentario,
  comentarioslist,
} from "../controllers/comentarios.js";

const router = express.Router();

router.post("/", criarComentario); 
router.delete("/:comentario_id", deletarComentario);
router.get("/" ,comentarioslist);


export default router;
