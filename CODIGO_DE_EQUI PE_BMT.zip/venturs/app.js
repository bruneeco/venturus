import express from "express";
import sequelize from "./database/database.js";
import publicacoesRoutes from "./routes/publicacoes.js";
import curtidasRoutes from "./routes/curtidas.js";
import seguidoresRoutes from "./routes/seguidores.js";
import comentariosRoutes from "./routes/comentarios.js";
import usuariosRoutes from "./routes/usuarios.js";
import Usuarios from './models/Usuarios.js';
import Publicacoes from './models/Publicacoes.js';
import Comentarios from './models/Comentarios.js';
import Seguidores from './models/Seguidores.js';

const app = express();

app.use(express.json());

// config de rotas
app.use("/publicacoes", publicacoesRoutes);
app.use("/curtidas", curtidasRoutes);
app.use("/seguidores", seguidoresRoutes);
app.use("/comentarios", comentariosRoutes);
app.use("/usuarios", usuariosRoutes);

// config de associacoes 
Usuarios.hasMany(Publicacoes, { foreignKey: 'usuario_id' });
Publicacoes.belongsTo(Usuarios, { foreignKey: 'usuario_id', as: 'usuario' });

Usuarios.hasMany(Comentarios, { foreignKey: 'usuario_id' });
Comentarios.belongsTo(Usuarios, { foreignKey: 'usuario_id' });

Publicacoes.hasMany(Comentarios, { foreignKey: 'publicacao_id' });
Comentarios.belongsTo(Publicacoes, { foreignKey: 'publicacao_id' });


// sincronizacao com banco de dados
sequelize.sync({ force: false })
    .then(() => console.log("Tabelas criadas com sucesso!"))
    .catch(error => console.error("Erro ao criar as tabelas:", error));
const port = process.env.PORT || 3002;
// inicializacao do servidor
const startServer = async () => {
    try {
        await sequelize.sync();
        app.listen(port, () => {
            console.log(`Servidor rodando na porta ${port}`);
        });
    } catch (error) {
        console.error("Erro ao iniciar o servidor:", error);
    }
};

startServer();
