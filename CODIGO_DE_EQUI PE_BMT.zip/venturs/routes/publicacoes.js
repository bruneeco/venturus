import express from "express";
import { 
  criarPublicacao, 
  listarPublicacoes, 
  listarPublicacoesDeUsuario, 
  deletarPublicacao 
} from "../controllers/publicacoes.js";

import { 
 listarComentarios,
} from "../controllers/comentarios.js";

const router = express.Router();


router.post("/", criarPublicacao);
router.get("/", listarPublicacoes);
router.get("/de/:usuario_id", listarPublicacoesDeUsuario);
router.delete("/", deletarPublicacao);
router.get("/:publicacao_id", listarComentarios);

export default router;
