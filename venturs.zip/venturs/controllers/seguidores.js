import Seguidores from "../models/Seguidores.js";
import Usuarios from "../models/Usuarios.js";

// seguir um usuario
export const seguirUsuario = async (req, res) => {
  const { usuario_id, usuario_a_seguir_id } = req.body;

  if (!usuario_id || !usuario_a_seguir_id) {
    return res.status(400).json({ erro: "Por favor, forneça ambos os IDs: o seu e o usuário que deseja seguir." });
  }

  if (usuario_id === usuario_a_seguir_id) {
    return res.status(400).json({ erro: "Você não pode seguir a si mesmo. Tente seguir outro usuário!" });
  }

  try {
    const usuarioASerSeguido = await Usuarios.findByPk(usuario_a_seguir_id);
    if (!usuarioASerSeguido) {
      return res.status(400).json({ erro: "O usuário que você está tentando seguir não foi encontrado. Verifique o ID e tente novamente." });
    }

    const jaSegue = await Seguidores.findOne({
      where: { usuario_id, seguidor_id: usuario_a_seguir_id },
    });
    if (jaSegue) {
      return res.status(400).json({ erro: "Você já está seguindo este usuário. Não é possível seguir duas vezes!" });
    }

    // cria o relacionamento de seguidor
    const seguidor = await Seguidores.create({ usuario_id, seguidor_id: usuario_a_seguir_id });

    res.status(201).json({ seguidor_id: seguidor.id });
  } catch (erro) {
    console.error("Erro ao seguir o usuário:", erro);
    res.status(500).json({ erro: "Houve um problema ao tentar seguir o usuário. Tente novamente mais tarde." });
  }
};

// deixar de seguir um usuario
export const deixarDeSeguir = async (req, res) => {
  const { usuario_id, usuario_a_seguir_id } = req.body;

  if (!usuario_id || !usuario_a_seguir_id) {
    return res.status(400).json({ erro: "Por favor, forneça ambos os IDs: o seu e o usuário que deseja deixar de seguir." });
  }

  try {
    // verifica se o relacionamento de seguimento existe
    const seguimento = await Seguidores.findOne({
      where: { usuario_id, seguidor_id: usuario_a_seguir_id },
    });

    if (!seguimento) {
      return res.status(400).json({ erro: "Você não está seguindo este usuário. Não há nada para remover!" });
    }

    // remove o relacionamento de seguimento
    await seguimento.destroy();

    res.status(200).json({ seguidor_id: seguimento.id });
  } catch (erro) {
    console.error("Erro ao deixar de seguir o usuário:", erro);
    res.status(500).json({ erro: "Houve um problema ao tentar deixar de seguir o usuário. Tente novamente mais tarde." });
  }
};

// listagem de seguidores de um usuario
export const listarSeguidores = async (req, res) => {
  const { usuario_id } = req.params; 
  const { page = 1, limit = 10 } = req.query;

  try {
    const seguidores = await Seguidores.findAndCountAll({
      where: { usuario_id: usuario_id }, 
      limit: parseInt(limit), 
      offset: (page - 1) * limit, 
      include: {
        model: Usuarios,
        as: 'seguidor',  
        attributes: ['id', 'nome', 'nick', 'imagem'],  
      },
    });
    res.status(200).json({
      data: seguidores.rows.map((seguidor) => seguidor.seguidor),  
      total: seguidores.count, 
      currentPage: parseInt(page),
      totalPages: Math.ceil(seguidores.count / limit),
    });
  } catch (erro) {
    console.error('Erro ao buscar seguidores:', erro);
    res.status(500).json({ erro: 'Houve um problema ao buscar os seguidores. Tente novamente mais tarde.' });
  }
};

// listagem de usuarios que um usuario segue
export const listarSeguindo = async (req, res) => {
  const { usuario_id } = req.params;  

  try {
    const seguindo = await Seguidores.findAndCountAll({
      where: { seguidor_id: usuario_id },  
      include: {
        model: Usuarios,
        as: 'seguido',  
        attributes: ['id', 'nome', 'nick', 'imagem'], 
      },
    });
    res.status(200).json({
      seguindo: seguindo.rows.map((segui) => segui.seguido), 
      total: seguindo.count,  
    });
  } catch (erro) {
    console.error('Erro ao buscar usuários seguidos:', erro);
    res.status(500).json({ erro: 'Houve um problema ao buscar os usuários seguidos. Tente novamente mais tarde.' });
  }
};


