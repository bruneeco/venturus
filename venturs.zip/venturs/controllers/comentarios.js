import Comentarios from "../models/Comentarios.js";
import Usuarios from "../models/Usuarios.js";
import Publicacoes from "../models/Publicacoes.js";

// criar um novo comentario em uma publicacao
export const criarComentario = async (req, res) => {
  const { publicacao_id, usuario_id, comentario } = req.body;

  if (!publicacao_id || !usuario_id || !comentario) {
    return res.status(400).json({ erro: "Campos obrigatórios: publicacao_id, usuario_id, comentario" });
  }

  try {
    const usuario = await Usuarios.findByPk(usuario_id);
    if (!usuario) return res.status(400).json({ erro: "Usuário não encontrado" });

    const publicacao = await Publicacoes.findByPk(publicacao_id);
    if (!publicacao) return res.status(400).json({ erro: "Publicação não encontrada" });

    const novoComentario = await Comentarios.create({ publicacao_id, usuario_id, comentario });
    res.status(201).json({ comentario_id: novoComentario.id });
  } catch (erro) {
    console.error("Erro ao criar comentário:", erro);
    res.status(500).json({ erro: "Erro ao criar comentário" });
  }
};

// listar comentarios de uma publicacaoo
export const listarComentarios = async (req, res) => {
  const { publicacao_id } = req.params;

  if (!publicacao_id) {
    return res.status(400).json({ erro: "Publicação não informada" });
  }

  try {
    const publicacao = await Publicacoes.findByPk(publicacao_id);
    if (!publicacao) return res.status(400).json({ erro: "Publicação não encontrada" });

    const comentarios = await Comentarios.findAll({
      where: { publicacao_id },
      include: [{ model: Usuarios, attributes: ['id', 'nick', 'imagem'] }],
      order: [['id', 'DESC']],
    });

    const comentariosFormatados = comentarios.map(comentario => ({
      comentario_id: comentario.id,
      comentario: comentario.comentario,
      usuario_id: comentario.usuario_id,
      nick: comentario.Usuario.nick,
      imagem: comentario.Usuario.imagem,
    }));

    res.status(200).json({ data: comentariosFormatados, total: comentariosFormatados.length });
  } catch (erro) {
    console.error("Erro ao buscar comentários:", erro);
    res.status(500).json({ erro: "Erro ao buscar comentários" });
  }
};

// deletar um comentario
export const deletarComentario = async (req, res) => {
  const { comentario_id, usuario_id } = req.body;

  if (!comentario_id || !usuario_id) {
    return res.status(400).json({ erro: "Comentário ou usuário não informado" });
  }

  try {
    const comentario = await Comentarios.findByPk(comentario_id);
    if (!comentario) return res.status(400).json({ erro: "Comentário não encontrado" });

    const usuario = await Usuarios.findByPk(usuario_id);
    if (!usuario) return res.status(400).json({ erro: "Usuário não encontrado" });

    if (comentario.usuario_id !== usuario_id) {
      return res.status(403).json({ erro: "Usuário não autorizado" });
    }

    await comentario.destroy();
    res.status(204).send(); 
  } catch (erro) {
    console.error("Erro ao deletar comentário:", erro);
    res.status(500).json({ erro: "Erro ao deletar comentário" });
  }
};
