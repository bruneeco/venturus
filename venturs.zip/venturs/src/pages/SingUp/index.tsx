export { SingUp } from "./SingUp";
