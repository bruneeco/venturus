export { PostDetail } from "./PostDetail";


