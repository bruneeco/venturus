export type ILikePost = {
    publicacao_id: string;
}

export type ILikeComment = {
    comentario_id: string;
}