export type IAddComment = {
  publicacao_id: string | undefined;
  usuario_id: string | undefined;
  comentario: string;
};
