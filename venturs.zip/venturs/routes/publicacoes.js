import express from "express";
import { 
  criarPublicacao, 
  listarPublicacoes, 
  listarPublicacoesDeUsuario, 
  deletarPublicacao 
} from "../controllers/publicacoes.js";

const router = express.Router();

router.post("/", criarPublicacao);
router.get("/", listarPublicacoes);
router.get("/de/:usuario_id", listarPublicacoesDeUsuario);
router.delete("/", deletarPublicacao);

export default router;
