import express from "express";
import { 
  criarComentario, 
  listarComentarios, 
  deletarComentario,
} from "../controllers/comentarios.js";

const router = express.Router();

router.post("/", criarComentario); 
router.get("/publicacao/:publicacao_id", listarComentarios); 
router.delete("/:comentario_id", deletarComentario);


export default router;
