import express from "express";
import {
  criarUsuario,
  listarUsuarios,
  buscarUsuarioPorId,
  atualizarUsuario,
} from "../controllers/usuarios.js";

const router = express.Router();

router.post("/", criarUsuario);
router.get("/", listarUsuarios);
router.get("/:usuario_id", buscarUsuarioPorId);
router.put("/:usuario_id", atualizarUsuario);

export default router;
