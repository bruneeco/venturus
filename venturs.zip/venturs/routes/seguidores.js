import express from "express";
import { seguirUsuario, deixarDeSeguir, listarSeguidores, listarSeguindo } from "../controllers/seguidores.js";

const router = express.Router();

router.post("/", seguirUsuario);
router.delete("/", deixarDeSeguir);
router.get("/:usuario_id", listarSeguidores);
router.get("/seguindo/:usuario_id", listarSeguindo);

export default router;
