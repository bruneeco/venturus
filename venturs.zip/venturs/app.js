import express from "express";
import sequelize from "./database/database.js";
import publicacoesRoutes from "./routes/publicacoes.js";
import curtidasRoutes from "./routes/curtidas.js";
import seguidoresRoutes from "./routes/seguidores.js";
import comentariosRoutes from "./routes/comentarios.js";
import usuariosRoutes from "./routes/usuarios.js";
import Usuarios from './models/Usuarios.js';
import Publicacoes from './models/Publicacoes.js';
import Comentarios from './models/Comentarios.js';
import Seguidores from './models/Seguidores.js';

const app = express();

app.use(express.json());

// config de rotas
app.use("/api/publicacoes", publicacoesRoutes);
app.use("/api/curtidas", curtidasRoutes);
app.use("/api/seguidores", seguidoresRoutes);
app.use("/api/comentarios", comentariosRoutes);
app.use("/api/usuarios", usuariosRoutes);

// config de associacoes 
Usuarios.hasMany(Publicacoes, { foreignKey: 'usuario_id' });
Publicacoes.belongsTo(Usuarios, { foreignKey: 'usuario_id' });

Usuarios.hasMany(Comentarios, { foreignKey: 'usuario_id' });
Comentarios.belongsTo(Usuarios, { foreignKey: 'usuario_id' });

Publicacoes.hasMany(Comentarios, { foreignKey: 'publicacao_id' });
Comentarios.belongsTo(Publicacoes, { foreignKey: 'publicacao_id' });

Seguidores.belongsTo(Usuarios, { foreignKey: 'seguidor_id', as: 'seguidor' });  
Seguidores.belongsTo(Usuarios, { foreignKey: 'usuario_id', as: 'seguido' }); 

// sincronizacao com banco de dados
sequelize.sync({ force: false })
    .then(() => console.log("Tabelas criadas com sucesso!"))
    .catch(error => console.error("Erro ao criar as tabelas:", error));

// inicializacao do servidor
const startServer = async () => {
    try {
        await sequelize.sync();
        app.listen(3000, () => console.log("Servidor rodando na porta 3000"));
    } catch (error) {
        console.error("Erro ao iniciar o servidor:", error);
    }
};

startServer();
